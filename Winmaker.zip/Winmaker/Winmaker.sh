mkdir Creacion
bash .banner
echo "Para que plataforma deseas crear malware:"
echo ""
echo "1)Para Windows"
echo "2)Para Linux"
echo "3)Ver Victimas"
echo "4)Ayuda"
echo "5)Salir"
echo ""
read input
bash .$input
