      _   _      ____  _ __   __
     | \ | | ___|  _ \| |\ \ / /_  __
     |  \| |/ _ \ |_) | __\ V /\ \/ /
     | |\  |  __/  __/| |_ | |  >  <
     |_| \_|\___|_|    \__||_| /_/\_\

Este repositorio esta hecho con fines educativos
e informativos cualquier mal uso que se le de el
creador no se hace responsable del uso cada quien
es responsable de sus acciones.

